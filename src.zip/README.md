# 勤工俭学后台管理系统 - 前端
### 技术实现
- React 18
- Ant Design Pro 5.x 脚手架
- Umi 4 前端框架
- Ant Design 组件库
### 开发环境
- WebStorm 
- Node 18.x
- npm 8.x
### 运行步骤
- npm install 安装依赖
- npm run dev 启动项目
- npm run build 打包项目
### 目前进度
- 登录注册
- 个人中心
- 用户管理
- 公告管理
