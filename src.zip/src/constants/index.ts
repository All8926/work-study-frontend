/**
 * 本地后端地址
 */
export const BACKEND_HOST_LOCAL = "http://localhost:8800";

/**
 * 线上后端地址
 */
export const BACKEND_HOST_PROD = "https://14.103.179.102:8204";
